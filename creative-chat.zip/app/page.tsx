"use client"

import Chat from "../chat"

export default function SyntheticV0PageForDeployment() {
  return <Chat />
}